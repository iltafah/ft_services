<?php
/**
 * The template used for displaying credits
 *
 * @package Signify
 */
?>

<?php
/**
 * signify_credits hook
 * @hooked signify_footer_content - 10
 */
do_action( 'signify_credits' );
